import numpy as np
from mlcvlab.nn.losses import l2, l2_grad
from mlcvlab.nn.basis import linear, linear_grad
from mlcvlab.nn.activations import relu, sigmoid, sigmoid_grad, relu_grad
from .base import Layer

class NN2():
    def __init__(self):
        self.layers = [Layer(None, relu, relu_grad), Layer(None, sigmoid, sigmoid_grad)]

    def nn2(self, x):
        layer1 = self.layers[0]
        layer2 = self.layers[1]
        W1 = layer1.W
        W2 = layer2.W
        sigma1 = layer1.activation
        sigma2 = layer2.activation
        y_hat = sigma2(linear(sigma1(linear(x, W1)), W2))
        return y_hat

    def grad(self, x, y, W):
        layer1 = self.layers[0]
        layer2 = self.layers[1]
        W1 = layer1.W
        W2 = layer2.W
        sigma1 = layer1.activation
        sigma2 = layer2.activation
        sigma1_grad = layer1.activation_grad
        sigma2_grad = layer2.activation_grad

        z1 = linear(x, W1)
        z1_tidle = sigma1(z1)
        z2 = linear(z1_tidle, W2)
        y_hat = sigma2(z2).T

        loss = l2(y, y_hat)
        print(loss)
        loss_grad = l2_grad(y, y_hat)
        grad_loss_wrt_z2 = np.multiply(loss_grad, sigma2_grad(z2).T)
        grad_loss_wrt_z1 = np.dot(W2, grad_loss_wrt_z2.T) * sigma1_grad(z1)
        grad_loss_wrt_W1 = np.dot(linear_grad(x), grad_loss_wrt_z1.T)
        grad_loss_wrt_W2 = np.dot(sigma1_grad(z1_tidle), grad_loss_wrt_z2)
        return [grad_loss_wrt_W1, grad_loss_wrt_W2]

    def emp_loss_grad(self, train_X, train_y, W, layer):
        N = train_X.shape[0]
        inv_N = 1 / N
        new_train_X = np.concatenate(
            (np.transpose(train_X), -1 * np.ones((1, N))))
        total_train_set_grad = self.grad(new_train_X, train_y, W)
        emp_loss_grad_0 = inv_N * total_train_set_grad[0]
        emp_loss_grad_1 = inv_N * total_train_set_grad[1]
        return [emp_loss_grad_0, emp_loss_grad_1]


    # ---- ---- -- if ran in loop --- ---- ----- ----

    # def emp_loss_grad(self, train_X, train_y, W):
        # emp_loss_grad_ = []
        # for i in range(len(train_X)):
        #     emp_loss_grad_.append(self.grad(np.append(train_X[i], -1), train_y[i], W))
        # return np.asarray([sum(x) for x in zip(*emp_loss_grad_)]) / len(train_X)


    # def grad(self, x, y, W):
    #     layer1 = self.layers[0]
    #     layer2 = self.layers[1]
    #     W1 = layer1.W
    #     W2 = layer2.W
    #     sigma1 = layer1.activation
    #     sigma2 = layer2.activation
    #     sigma1_grad = layer1.activation_grad
    #     sigma2_grad = layer2.activation_grad

    #     z1 = linear(x, W1)
    #     z1_tidle = sigma1(z1)
    #     z2 = linear(z1_tidle, W2)
    #     y_hat = sigma2(z2)
        
    #     loss_grad = l2_grad(y, y_hat)
    #     grad_loss_wrt_z2 = np.multiply(loss_grad, sigma2_grad(z2))
    #     grad_loss_wrt_z1 = np.dot(W2, grad_loss_wrt_z2.T) * sigma1_grad(z1)
    #     grad_loss_wrt_W1 = np.dot(np.array([linear_grad(x)]).T, np.array([grad_loss_wrt_z1]))
    #     grad_loss_wrt_W2 = np.dot(np.array([sigma1_grad(z1_tidle)]).T, np.array([grad_loss_wrt_z2]))
    #     return [grad_loss_wrt_W1, grad_loss_wrt_W2]