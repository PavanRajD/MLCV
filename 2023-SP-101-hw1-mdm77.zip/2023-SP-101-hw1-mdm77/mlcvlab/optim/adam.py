# No additional 3rd party external libraries are allowed
import numpy as np

def Adam(model,  train_X, train_y):
    ALPHA = 0.001
    BETA_1 = 0.9
    BETA_2 = 0.99
    EPSLON = 1e-9
    R = 100
    INPUT_LAYER_NEURONS = train_X.shape[1]
    HIDDEN_LAYER_NEURONS = 400

    old_M1 = np.zeros((INPUT_LAYER_NEURONS + 1, HIDDEN_LAYER_NEURONS + 1))
    old_S1 = np.zeros((INPUT_LAYER_NEURONS + 1, HIDDEN_LAYER_NEURONS + 1))

    old_M2 = np.zeros((HIDDEN_LAYER_NEURONS + 1, 1))
    old_S2 = np.zeros((HIDDEN_LAYER_NEURONS + 1, 1))

    for i in range(R):
        old_W1 = model.layers[0].W
        old_W2 = model.layers[1].W
        new_W = [old_W1, old_W2]

        emp_loss_grad_no_momemtum = model.emp_loss_grad(train_X, train_y, new_W, -1)
        model.layers[0].W += BETA_1 * old_M1
        model.layers[1].W += BETA_1 * old_M2
        emp_loss_grad_with_momemtum = model.emp_loss_grad(train_X, train_y, new_W, -1)

        new_M1 = BETA_1 * old_M1 + (1 - BETA_1) * emp_loss_grad_with_momemtum[0]
        new_S1 = BETA_2 * old_S1 + (1 - BETA_2) * np.power(emp_loss_grad_no_momemtum[0], 2)

        new_M2 = BETA_1 * old_M2 + (1 - BETA_1) * emp_loss_grad_with_momemtum[1]
        new_S2 = BETA_2 * old_S2 + (1 - BETA_2) * np.power(emp_loss_grad_no_momemtum[1], 2)

        model.layers[0].W = old_W1 - ((ALPHA / (np.sqrt(new_S1) + EPSLON)) * new_M1)
        model.layers[1].W = old_W2 - ((ALPHA / (np.sqrt(new_S2) + EPSLON)) * new_M2)

        old_M1 = new_M1
        old_M2 = new_M2
        old_S1 = new_S1
        old_S2 = new_S2
        print(f"Iteration: {i} completed")

    return [model.layers[0].W, model.layers[1].W]
