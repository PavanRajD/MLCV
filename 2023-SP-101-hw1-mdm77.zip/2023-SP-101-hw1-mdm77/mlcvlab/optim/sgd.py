# No additional 3rd party external libraries are allowed
import random
import numpy as np

from mlcvlab.optim import HIDDEN_LAYER_NEURONS

def SGD(model, train_X, train_y, lr=0.1, R=100):
    INPUT_LAYER_NEURONS = train_X.shape[1]

    for i in range(R):
        print(f"Iteration: {i} started")
        old_W1 = model.layers[0].W
        old_W2 = model.layers[1].W

        w1_r = np.zeros([INPUT_LAYER_NEURONS + 1, HIDDEN_LAYER_NEURONS + 1])
        w2_r = np.zeros([INPUT_LAYER_NEURONS + 1, HIDDEN_LAYER_NEURONS + 1])

        rand_row_in_w1 = random.choice(range(0, old_W1.shape[0]))
        rand_col_in_w1 = random.choice(range(0, old_W1.shape[1]))
        rand_row_in_w2 = rand_col_in_w1

        jth_element_w1 = old_W1[rand_row_in_w1, rand_col_in_w1]
        jth_element_w2 = old_W2[rand_row_in_w2]

        w1_r[rand_row_in_w1, rand_col_in_w1] = jth_element_w1
        w2_r[rand_row_in_w2] = jth_element_w2

        new_W = [w1_r, w2_r]

        emp_loss_grad_ = model.emp_loss_grad(train_X, train_y, new_W, -1)

        model.layers[0].W = old_W1 - (lr * emp_loss_grad_[0])
        model.layers[1].W = old_W2 - (lr * emp_loss_grad_[1].reshape(old_W2.shape[0],1))
        print(f"Iteration: {i} completed")  

    return [model.layers[0].W, model.layers[1].W]