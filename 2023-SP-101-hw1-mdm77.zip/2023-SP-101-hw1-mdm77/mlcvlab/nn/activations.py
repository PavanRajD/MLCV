# No additional 3rd party external libraries are allowed
import numpy as np

def relu(x):
    return (x >= 0) * x

def relu_grad(z):
     return (z > 0) * 1

def sigmoid(x):
    return 1 / (1 + np.exp(-x))
    
def sigmoid_grad(z):
    return z * (1 - z)

def softmax(x):
    expX = np.exp(x)
    return np.divide(expX, np.transpose(np.tile(np.sum(expX, axis=1), (np.shape(x)[1], 1))))
    
def softmax_grad(z):
    z_shape = np.shape(z)[1]
    return np.multiply(-1 * np.tile(np.transpose(z), (1, z_shape)), np.tile(z, (z_shape, 1)) - np.identity(z_shape))

def tanh(x):
    return np.tanh(x)

def tanh_grad(z):
    return 1 - np.square(tanh(z))
