# No additional 3rd party external libraries are allowed
import numpy as np

def linear(x, W):
    return np.dot(W.T, x)
    
def linear_grad(x):
    return x

def radial(x, W):
    return np.square(np.linalg.norm(x - W, ord=2))
    
def radial_grad(loss_grad_y, x, W):
    return np.exp((-1 * loss_grad_y) * (x- W)**2)