# No additional 3rd party external libraries are allowed
import numpy as np
from numpy.linalg import norm 

def l2(y, y_hat):
    return np.linalg.norm(y - y_hat, ord=2)

def l2_grad(y, y_hat):
    return np.divide((y - y_hat), l2(y, y_hat))

def cross_entropy(A, Y):
    return np.multiply(-A, np.log(Y)) - np.multiply((1 - A), np.log(1 - Y))
    
def cross_entropy_grad(y, y_hat):
    return np.divide(1 - y, 1 - y_hat) - np.divide(y, y_hat)