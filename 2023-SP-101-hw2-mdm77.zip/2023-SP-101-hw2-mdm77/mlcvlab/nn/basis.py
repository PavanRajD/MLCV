# No additional 3rd party external libraries are allowed
import numpy as np
from mlcvlab.nn.dropout import dropout, dropout_grad


def linear(x, W, p=0.5, mode="test"):
    return dropout(np.dot(x, W), p, mode)


def linear_grad(x, mask, mode="test"):
    return dropout_grad(x, mask, mode)


def radial(x, W):
    return np.square(np.linalg.norm(x - W, ord=2))


def radial_grad(loss_grad_y, x, W):
    return np.exp((-1 * loss_grad_y) * (x - W)**2)
