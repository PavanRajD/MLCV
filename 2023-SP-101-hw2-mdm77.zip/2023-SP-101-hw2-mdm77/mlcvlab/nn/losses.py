# No additional 3rd party external libraries are allowed
import numpy as np


def l2(y, y_hat):
    return np.mean(np.square(y - y_hat))


def l2_grad(y, y_hat):
    return np.divide(2 * (y_hat - y), len(y))


def cross_entropy(y, y_hat):
    eps = 1e-8
    return -np.mean(np.multiply(y, np.log(y_hat + eps))) + np.multiply((1 - y), np.log(1 - y_hat + eps))


def cross_entropy_grad(y, y_hat):
    N = y.shape[0]
    eps = 1e-8
    return -(np.divide(y, y_hat + eps) - np.divide(1 - y, 1 - y_hat + eps)) / N
