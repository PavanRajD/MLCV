# No additional 3rd party external libraries are allowed
import numpy as np


def SGD(model,  train_X, train_y, lr=0.1, R=100):
    #Updated_Weights = None
    #TODO
    #return Updated_Weights
    raise NotImplementedError("SGD not implemented")
