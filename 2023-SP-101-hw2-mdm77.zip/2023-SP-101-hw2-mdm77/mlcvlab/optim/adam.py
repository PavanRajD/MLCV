# No additional 3rd party external libraries are allowed
import numpy as np

def Adam(model,  train_X, train_y):
    #TODO
    raise NotImplementedError("Adam Not Implemented")